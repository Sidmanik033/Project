TRIBUTE TO NIKOLA TESLA
------------------------
 		This is Web Development Technology Mini Project On topic : Tribute To NIKOLA TESLA
		 I extend my Gratitude To Doc. Ashish Kulkarni (HOD MCA Dept MITWPU) and Prof. Sagar Kulkarni for providing me this opportunity.   

 CONTENTS OF THE FILE
 --------------------

	- Home Page
	- Introduction Page
	- Invention Page
	- Museum Page
	- Contact Us

	In addtion to these HTML files it also contains CSS files and images for the same.

OPENING THE PROJECT
--------------------

	**TO OPEN THE PROJECT PLEASE CLICK ON THE "home" HTML FILE.**

TEAM MEMBERS
------------
	PRANALI JADHAV (20MCA018)
	GAURAV MAKASARE (20MCA034)
	NIKITA VALLECHA (20MCA061)
	SIDDHANT MANIK (20MCA065)




